execute as @e[type=#pda:aj_root,tag=aj.pda.root] run function zzz_pda_internal:remove/as_root
kill @e[tag=aj.pda.rig_entity]