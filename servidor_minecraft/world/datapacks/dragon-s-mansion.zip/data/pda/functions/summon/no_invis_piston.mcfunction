scoreboard players set #variant aj.i 1
function pda:summon