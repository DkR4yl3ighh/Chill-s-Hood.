execute as @e[tag=aj.pda.animation.leave_lope,tag=!pda_ll_st,tag=!pda_ll_sl] at @s run summon minecraft:block_display ^0.5 ^0.9 ^-1.75 {block_state:{Name:"minecraft:cherry_leaves"},Tags:[leave_lope],Rotation:[0f,-60f],scale:[1f,1f,1f]}
execute as @e[tag=aj.pda.animation.leave_lope,tag=!pda_ll_st,tag=!pda_ll_sl] at @s run summon minecraft:block_display ^0.5 ^0.9 ^-1.75 {block_state:{Name:"minecraft:cherry_leaves"},Tags:[leave_lope],Rotation:[0f,-60f],scale:[1f,1f,1f]}
execute as @e[tag=aj.pda.animation.leave_lope,tag=!pda_ll_st,tag=!pda_ll_sl] at @s run summon minecraft:block_display ^0.5 ^0.9 ^-1.75 {block_state:{Name:"minecraft:cherry_leaves"},Tags:[leave_lope],Rotation:[0f,-60f],scale:[1f,1f,1f]}
execute as @e[tag=aj.pda.animation.leave_lope,tag=!pda_ll_st,tag=!pda_ll_sl] at @s as @e[limit=3,sort=nearest,tag=leave_lope] positioned as @s run tp @s ~ ~ ~ ~180 -60
execute as @e[tag=aj.pda.animation.leave_lope,tag=!pda_ll_st,tag=!pda_ll_sl] run tag @s remove pda_r

execute if entity @s[tag=pda_ll_st] run function pda:animations/leave_lope/play
execute if entity @s[tag=pda_ll_st] run tag @s add pda_r


execute as @e[tag=ll_launched] at @s run tp @s ^ ^ ^1.5
tag @e[tag=ll_launched] remove ll_launched
execute as @e[tag=aj.pda.animation.leave_lope,tag=pda_ll_sl] at @s if entity @e[distance=..3,tag=!ll_launched,tag=leave_lope] as @e[limit=1,sort=nearest,tag=leave_lope] run tag @s add ll_launched

execute as @e[tag=leave_lope] at @s unless entity @e[tag=aj.pda.root,distance=..20] unless entity @e[tag=leave_lope_goal,distance=..100] at @p run summon marker ~ ~ ~ {Tags:[leave_lope_goal]}
execute as @e[tag=leave_lope] at @s if entity @e[tag=leave_lope_goal,distance=10..] facing entity @e[tag=leave_lope_goal,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=leave_lope] at @s run tp @s ^ ^ ^1.5

#effects
execute at @e[tag=leave_lope_goal] run particle minecraft:dust 255 0 0 1 ~ ~ ~ 1 0.2 1 1 125 normal
execute at @e[tag=leave_lope] run particle minecraft:item cherry_leaves ~ ~ ~ 0.00125 0.00125 0.00125 1 5 normal


#impact
execute as @e[tag=leave_lope] at @s if entity @a[distance=..2] run playsound minecraft:block.cherry_leaves.step neutral @a[distance=..10] ~ ~ ~ 10 0.4
execute as @e[tag=leave_lope] at @s as @a[distance=..2] run function dragon:attacks/cherry_dmg/leave_lope_dmg
execute as @e[tag=leave_lope] at @s as @a[distance=..2] run scoreboard players add @s cherry_effect 40
execute as @e[tag=leave_lope] at @s if entity @a[distance=..2] run kill @s

execute as @e[tag=leave_lope] at @s if entity @e[tag=leave_lope_goal,distance=..5] unless block ^ ^ ^1 air run playsound minecraft:block.cherry_leaves.step neutral @a[distance=..10] ~ ~ ~ 10 0.4
execute as @e[tag=leave_lope] at @s if entity @e[tag=leave_lope_goal,distance=..5] unless block ^ ^ ^1 air run particle minecraft:dust 0.855 0.012 0.529 1 ~ ~ ~ 0.5 .5 .5 3 20 normal
execute as @e[tag=leave_lope] at @s if entity @e[tag=leave_lope_goal,distance=..5] unless block ^ ^ ^1 air run kill @s
execute as @e[tag=leave_lope] at @s if entity @e[tag=leave_lope_goal,distance=..5] unless block ^ ^ ^ air run playsound minecraft:block.cherry_leaves.step neutral @a[distance=..10] ~ ~ ~ 10 0.4
execute as @e[tag=leave_lope] at @s if entity @e[tag=leave_lope_goal,distance=..5] unless block ^ ^ ^ air run particle minecraft:dust 0.855 0.012 0.529 1 ~ ~ ~ 0.5 .5 .5 3 20 normal
execute as @e[tag=leave_lope] at @s if entity @e[tag=leave_lope_goal,distance=..5] unless block ^ ^ ^ air run kill @s


execute as @e[tag=aj.pda.animation.leave_lope,tag=!pda_ll_st,limit=1] run tag @s add pda_ll_sl
execute as @e[tag=aj.pda.animation.leave_lope,tag=pda_ll_sl,limit=1] run schedule function dragon:attacks/leave_lope 1t replace
execute as @e[tag=leave_lope,limit=1] at @s unless entity @e[tag=aj.pda.animation.leave_lope,tag=pda_ll_sl] run schedule function dragon:attacks/leave_lope 1t replace

tag @s add pda_do_no
execute if entity @s[tag=pda_ll_st] run schedule function dragon:attacks/leave_lope 15t replace
tag @s remove pda_ll_st

#end
execute as @e[tag=leave_lope_goal] at @s unless entity @e[tag=leave_lope,distance=..30] run tag @e[tag=aj.pda.root,limit=1,sort=nearest] remove pda_ll_sl
execute as @e[tag=leave_lope_goal] at @s unless entity @e[tag=leave_lope,distance=..30] run kill @s

#Plan
#summon the block displays (3)
#wait short
#rotate them to player
#tp like 10 times up and a bit forth
#tp like 10 times up and a bit forth and land at player
#a bit cherry effect but huge dmg, bit area dmg
