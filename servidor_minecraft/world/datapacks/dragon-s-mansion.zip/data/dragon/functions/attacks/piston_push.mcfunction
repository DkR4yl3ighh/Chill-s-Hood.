execute as @e[tag=aj.pda.animation.piston_push,tag=!pda_p_st,tag=pda_r] at @s positioned as @a[limit=1,sort=nearest] facing entity @e[limit=1,sort=nearest,tag=aj.pda.root] eyes run summon minecraft:armor_stand ~ ~-1 ~ {Tags:[pda_pp_r],Invisible:1b}
execute as @e[tag=aj.pda.animation.piston_push,tag=!pda_p_st,tag=pda_r] at @s as @a[limit=1,sort=nearest] at @s run ride @s mount @e[limit=1,tag=pda_pp_r,sort=nearest]

tag @e remove pda_r
execute if entity @s[tag=pda_p_st] run function pda:animations/piston_push/play
execute if entity @s[tag=pda_p_st] run schedule function dragon:attacks/piston_push 15t
tag @s[tag=pda_p_st] add pda_r
tag @s remove pda_p_st

execute as @e[tag=pda_pp_r] positioned as @s facing entity @e[tag=aj.pda.root,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ 0
execute as @e[tag=pda_pp_r] at @s at @p unless block ^ ^ ^-1.25 air run tag @e[limit=1,sort=nearest,tag=aj.pda.root] add pda_do_no
execute as @e[tag=pda_pp_r] at @s at @p unless block ^ ^ ^-1.25 air run effect give @p nausea 6 0 false
execute as @e[tag=pda_pp_r] at @s at @p unless block ^ ^ ^-1.25 air run effect give @p slowness 6 9 false
execute as @e[tag=pda_pp_r] at @s at @p unless block ^ ^ ^-1.25 air run damage @p 8 mob_attack
execute as @e[tag=pda_pp_r] at @s at @p unless block ^ ^ ^-1.25 air run kill @s
execute as @e[tag=pda_pp_r] at @s run tp @s ^ ^0.125 ^-1.25
execute as @e[tag=pda_pp_r] at @s run ride @p mount @s


execute as @e[tag=pda_pp_r,limit=1] run schedule function dragon:attacks/piston_push 1t replace