scoreboard players add seconds pda_attack 1
execute if score seconds pda_attack matches 6.. run scoreboard players set seconds pda_attack 1
execute if score seconds pda_attack matches 5.. as @e[tag=aj.pda.root,tag=pda_do_no] at @s run function dragon:attacks/main
schedule function dragon:attacks/attack_seconds 1s replace 