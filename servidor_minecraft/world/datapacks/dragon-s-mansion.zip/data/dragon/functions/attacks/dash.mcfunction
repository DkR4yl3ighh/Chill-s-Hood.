execute if entity @s[tag=pda_d_st] run function pda:animations/fly/play
execute if entity @s[tag=pda_d_st] as @e[tag=dragon_box,limit=1,sort=nearest] at @s facing entity @a[distance=..25,limit=1,sort=furthest] eyes run tp @s ~ ~ ~ ~ 0
execute if entity @s[tag=pda_d_st] run tag @s add pda_t
tag @e remove pda_d_st
execute as @e[tag=aj.pda.animation.fly] at @s as @e[limit=1,sort=nearest,tag=dragon_box] at @s run tp ^ ^ ^0.75
execute as @e[tag=aj.pda.animation.fly] at @s as @e[limit=1,sort=nearest,tag=dragon_box] at @s if block ~ ~-1 ~ air run tp ^ ^-1 ^
execute as @e[tag=aj.pda.animation.fly] at @s as @e[limit=1,sort=nearest,tag=dragon_box] at @s unless block ~ ~ ~ air run tp ^ ^1 ^
execute as @e[tag=aj.pda.animation.fly] at @s at @e[tag=dragon_box,limit=1,sort=nearest] run tp @s ~ ~0.9 ~ ~ ~
execute as @e[tag=aj.pda.animation.fly] at @s run effect give @a[distance=..5] nausea 8 0 false
execute as @e[tag=aj.pda.animation.fly] at @s run effect give @a[distance=..5] slowness 6 4 false
execute as @e[tag=aj.pda.animation.fly] at @s run damage @a[distance=..5,limit=1] 3 explosion at ~ ~ ~
execute as @e[tag=aj.pda.animation.fly] at @s as @a[distance=..5] at @s facing entity @e[limit=1,sort=nearest,tag=aj.pda.root] eyes run tp @s ~ ~ ~ ~ 0
execute as @e[tag=aj.pda.animation.fly] at @s as @a[distance=..5] at @s if block ^ ^ ^-0.8 air run tp ^ ^ ^-0.8
execute as @e[tag=aj.pda.animation.fly] at @s unless block ^ ^1 ^4 air run tag @s add pda_do_no
execute as @e[tag=aj.pda.animation.fly] at @s unless block ^ ^1 ^4 air run tag @s remove pda_r
execute as @e[tag=aj.pda.animation.fly] at @s unless block ^ ^1 ^4 air run tag @s remove pda_t
execute as @e[tag=aj.pda.animation.fly] at @s unless block ^ ^1 ^4 air run function pda:animations/fly/stop 
execute as @e[tag=aj.pda.animation.fly] at @s if block ^ ^1 ^4 air run schedule function dragon:attacks/dash 1t replace 