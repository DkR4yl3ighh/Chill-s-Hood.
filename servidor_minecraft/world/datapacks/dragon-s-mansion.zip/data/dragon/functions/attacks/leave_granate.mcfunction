execute if entity @s[tag=pda_lg_st] run function pda:animations/fly/play
execute if entity @s[tag=pda_lg_st] run tag @s add pda_t
execute if entity @s[tag=pda_lg_st] run tag @s add pda_lg_sl
execute if entity @s[tag=pda_lg_st] as @e[tag=dragon_box,limit=1,sort=nearest] at @s facing entity @e[limit=1,sort=nearest,tag=pda_fly_spot] feet run tp @s ~ ~ ~ ~ ~
execute as @e[tag=aj.pda.animation.fly] at @s as @e[limit=1,sort=nearest,tag=dragon_box] at @s run tp ^ ^ ^0.75

#summon the grenade
execute as @e[tag=pda_lg_sl,tag=pda_r,tag=!pda_do_no] at @s at @e[tag=dragon_box,limit=1,sort=nearest] if entity @e[distance=..1,tag=pda_fly_spot] unless entity @e[tag=leave_grenade,distance=..100] unless entity @e[tag=Cherry_Cloud_M,distance=..100] unless entity @e[tag=Cherry_Cloud,distance=..100] at @s run summon minecraft:block_display ^0.5 ^0.9 ^-1.5 {block_state:{Name:"minecraft:cherry_leaves"},Tags:[leave_grenade],Rotation:[0f,0f],scale:[4f,4f,4f]} 
execute as @e[tag=leave_grenade] run data merge entity @s {block_state:{Name:"minecraft:cherry_leaves"},Tags:[leave_grenade],transformation:{scale:[2.0f,2.0f,2.0f]}}
execute as @e[tag=pda_lg_sl,tag=pda_r,tag=!pda_do_no] at @s at @e[tag=dragon_box,limit=1,sort=nearest] if entity @e[distance=..1,tag=pda_fly_spot] if entity @e[tag=leave_grenade,distance=..3] unless entity @e[tag=Cherry_Cloud_M,distance=..100] unless entity @e[tag=Cherry_Cloud,distance=..100] as @r[distance=..40] at @s run summon marker ~ ~ ~ {Tags:[Cherry_Cloud_M]}
execute as @e[tag=pda_lg_sl,tag=pda_r,tag=!pda_do_no] at @s at @e[tag=dragon_box,limit=1,sort=nearest] if entity @e[distance=..1,tag=pda_fly_spot] if entity @e[tag=leave_grenade,distance=..3] if entity @e[tag=Cherry_Cloud_M,distance=..100] unless entity @e[tag=Cherry_Cloud,distance=..100] run tag @s remove pda_r


#move the grenade
execute as @e[tag=leave_grenade] at @s facing entity @e[limit=1,sort=nearest,tag=Cherry_Cloud_M] feet run tp @s ^ ^ ^1

#impact
execute as @e[tag=leave_grenade] at @s if entity @a[distance=..3] run summon minecraft:area_effect_cloud ~ ~ ~ {Duration:161,Tags:[Cherry_Cloud],Radius:5,Effects:[{Id:18,Duration:2,Amplifier:1,ShowIcon:true}]}
execute as @e[tag=leave_grenade] at @s if entity @a[distance=..3] run kill @s

execute as @e[tag=leave_grenade] at @s if entity @e[tag=Cherry_Cloud_M,distance=..0.6] run summon minecraft:area_effect_cloud ^ ^ ^2 {Duration:101,Tags:[Cherry_Cloud],Radius:5,Effects:[{Id:18,Duration:160,Amplifier:0,ShowIcon:true}]}
execute as @e[tag=leave_grenade] at @s if entity @e[tag=Cherry_Cloud_M,distance=..0.6] run kill @s

execute as @e[tag=Cherry_Cloud] at @s run kill @e[limit=1,sort=nearest,tag=Cherry_Cloud_M,distance=..100]

#Cherry Cloud
execute as @e[tag=Cherry_Cloud] at @s run scoreboard players add @a[distance=..4] cherry_effect 1
execute as @e[tag=Cherry_Cloud] at @s run particle minecraft:item cherry_leaves ~ ~ ~ 4 4 4 0.1 150 normal
execute as @e[tag=Cherry_Cloud] at @s run particle minecraft:dust 0.318 0 0.467 1 ~ ~ ~ 4 4 4 0.1 250 normal
execute as @e[tag=Cherry_Cloud] at @s run playsound minecraft:block.cherry_leaves.place neutral @a[distance=..16] ~ ~ ~ 0.7 0.5 1
execute as @e[tag=Cherry_Cloud] at @s as @a[distance=..5] run function dragon:attacks/cherry_dmg/leave_grenate_dmg

#destroy
execute as @e[tag=Cherry_Cloud,nbt={Age:100}] at @s run tag @e[limit=1,sort=nearest,tag=aj.pda.root] add pda_do_no
execute as @e[tag=Cherry_Cloud,nbt={Age:100}] at @s run tag @e[limit=1,sort=nearest,tag=aj.pda.root] remove pda_lg_sl
execute as @e[tag=Cherry_Cloud,nbt={Age:100}] at @s run say removed and added   

#on spot
execute as @e[tag=pda_lg_sl,tag=!pda_r] at @s at @e[tag=dragon_box,limit=1,sort=nearest] if entity @e[distance=..1,tag=pda_fly_spot] run function pda:animations/fly/stop
execute as @e[tag=pda_lg_sl,tag=!pda_r] at @s at @e[tag=dragon_box,limit=1,sort=nearest] if entity @e[distance=..1,tag=pda_fly_spot] run function pda:animations/leave_grenate/play
execute as @e[tag=pda_lg_sl,tag=!pda_r] at @s at @e[tag=dragon_box,limit=1,sort=nearest] if entity @e[distance=..1,tag=pda_fly_spot] run tag @s remove pda_t
execute as @e[tag=pda_lg_sl] at @s at @e[tag=dragon_box,limit=1,sort=nearest] if entity @e[distance=..1,tag=pda_fly_spot] if entity @e[distance=..1,tag=pda_fly_spot] unless entity @e[tag=leave_grenade,distance=..100] unless entity @e[tag=Cherry_Cloud_M,distance=..100] unless entity @e[tag=Cherry_Cloud,distance=..100] run tag @s add pda_r

execute as @e[tag=pda_lg_sl,tag=!pda_r,limit=1] run schedule function dragon:attacks/leave_granate 1t replace
execute as @e[tag=pda_lg_sl,tag=pda_r,limit=1] run schedule function dragon:attacks/leave_granate 30t replace
tag @s remove pda_lg_st

#fly to armor stand
#spawn marker in front of player
#look at marker
#when animation, summon big leave
#move leave to marker
#when marker hits player of marker delete itself
#make a cherry cloud which damages and increases cherry effects aswell as blindness caused by the particles
#weakness lingering potion there, then kill it 

#why sl? Ive got no idea