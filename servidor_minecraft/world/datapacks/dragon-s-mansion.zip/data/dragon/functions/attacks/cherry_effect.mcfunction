scoreboard players remove @e[scores={cherry_effect=1..}] cherry_effect 2
scoreboard players set @e[scores={cherry_effect=210..}] cherry_effect 210
scoreboard players reset @e[scores={cherry_death=1..}] cherry_effect
scoreboard players reset @e cherry_death

#Cherry Particles
execute as @e[scores={cherry_effect=1..10}] at @s run particle minecraft:block cherry_leaves ~ ~ ~ 1 1 1 1 10 normal
execute as @e[scores={cherry_effect=11..20}] at @s run particle minecraft:block cherry_leaves ~ ~ ~ 1 1 1 1 20 normal
execute as @e[scores={cherry_effect=21..30}] at @s run particle minecraft:block cherry_leaves ~ ~ ~ 1 1 1 1 30 normal
execute as @e[scores={cherry_effect=31..40}] at @s run particle minecraft:block cherry_leaves ~ ~ ~ 1 1 1 1 40 normal
execute as @e[scores={cherry_effect=41..50}] at @s run particle minecraft:block cherry_leaves ~ ~ ~ 1 1 1 1 50 normal
execute as @e[scores={cherry_effect=51..60}] at @s run particle minecraft:block cherry_leaves ~ ~ ~ 1 1 1 1 60 normal
execute as @e[scores={cherry_effect=61..70}] at @s run particle minecraft:block cherry_leaves ~ ~ ~ 1 1 1 1 70 normal
execute as @e[scores={cherry_effect=71..80}] at @s run particle minecraft:block cherry_leaves ~ ~ ~ 1 1 1 1 80 normal
execute as @e[scores={cherry_effect=81..90}] at @s run particle minecraft:block cherry_leaves ~ ~ ~ 1 1 1 1 90 normal
execute as @e[scores={cherry_effect=91..100}] at @s run particle minecraft:block cherry_leaves ~ ~ ~ 1 1 1 1 100 normal
execute as @e[scores={cherry_effect=101..110}] at @s run particle minecraft:block cherry_leaves ~ ~ ~ 1 1 1 1 110 normal
execute as @e[scores={cherry_effect=111..120}] at @s run particle minecraft:block cherry_leaves ~ ~ ~ 1 1 1 1 120 normal
execute as @e[scores={cherry_effect=121..130}] at @s run particle minecraft:block cherry_leaves ~ ~ ~ 1 1 1 1 130 normal
execute as @e[scores={cherry_effect=131..140}] at @s run particle minecraft:block cherry_leaves ~ ~ ~ 1 1 1 1 140 normal
execute as @e[scores={cherry_effect=141..150}] at @s run particle minecraft:block cherry_leaves ~ ~ ~ 1 1 1 1 150 normal
execute as @e[scores={cherry_effect=151..160}] at @s run particle minecraft:block cherry_leaves ~ ~ ~ 1 1 1 1 160 normal
execute as @e[scores={cherry_effect=161..170}] at @s run particle minecraft:block cherry_leaves ~ ~ ~ 1 1 1 1 170 normal
execute as @e[scores={cherry_effect=171..180}] at @s run particle minecraft:block cherry_leaves ~ ~ ~ 1 1 1 1 180 normal
execute as @e[scores={cherry_effect=181..190}] at @s run particle minecraft:block cherry_leaves ~ ~ ~ 1 1 1 1 190 normal
execute as @e[scores={cherry_effect=191..}] at @s run particle minecraft:block cherry_leaves ~ ~ ~ 1 1 1 1 200 normal


schedule function dragon:attacks/cherry_effect 1s replace