execute if entity @s[tag=pda_sh_st] run function pda:animations/shoot_leave/play
execute if entity @s[tag=pda_sh_st] as @e[tag=dragon_box,limit=1,sort=nearest] at @s facing entity @a[limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ 0
execute if entity @s[tag=pda_sh_st] at @s at @e[tag=dragon_box,limit=1,sort=nearest] run tp @s ~ ~0.9 ~ ~180 0

execute as @e[tag=pda_sh_sl,tag=aj.pda.root] at @s run summon minecraft:block_display ^ ^ ^-3 {block_state:{Name:"minecraft:cherry_leaves"},Tags:[leave_bullet],Rotation:[0f,0f],scale:[0.8f,0.8f,0.8f]}
execute as @e[tag=leave_bullet] run data merge entity @s {block_state:{Name:"minecraft:cherry_leaves"},transformation:{scale:[0.75f,0.75f,0.75f]}}
execute as @e[tag=pda_sh_sl,tag=aj.pda.root] at @s positioned ^ ^ ^3 as @e[tag=leave_bullet,limit=1,sort=nearest] at @s facing entity @p[] eyes run tp @s ~ ~ ~ ~ ~

execute as @e[tag=!pda_sh_st,tag=aj.pda.root] at @s positioned ^ ^ ^3 as @e[tag=leave_bullet,limit=1,sort=nearest] at @s facing entity @p[] feet if entity @p[distance=..4] run tp @s ~ ~ ~ ~ ~
execute as @e[tag=!pda_sh_st,tag=aj.pda.root] at @s positioned ^ ^ ^3 as @e[tag=leave_bullet,limit=1,sort=nearest] at @s run tp @s ^ ^ ^1
execute as @e[tag=!pda_sh_st,tag=aj.pda.root] at @s positioned ^ ^ ^3 as @e[tag=leave_bullet,limit=1,sort=nearest] at @s run particle minecraft:item cherry_leaves ~ ~ ~ 0.00125 0.00125 0.00125 1 5 normal
execute as @e[tag=!pda_sh_st,tag=aj.pda.root] at @s positioned ^ ^ ^3 as @e[tag=leave_bullet,limit=1,sort=nearest] at @s as @e[distance=..1.7,limit=1,sort=nearest,type=!minecraft:block_display] at @s run function dragon:attacks/cherry_dmg/shoot_dmg
execute as @e[tag=!pda_sh_st,tag=aj.pda.root] at @s positioned ^ ^ ^3 as @e[tag=leave_bullet,limit=1,sort=nearest] at @s run scoreboard players add @e[distance=..1.7,limit=1,sort=nearest,type=!minecraft:block_display] cherry_effect 40

execute as @e[tag=!pda_sh_st,tag=aj.pda.root] at @s positioned ^ ^ ^3 as @e[tag=leave_bullet,limit=1,sort=nearest] at @s if entity @a[distance=..1.7,limit=1,sort=nearest] run tag @e[limit=1,sort=nearest,tag=aj.pda.root] add pda_do_no
execute as @e[tag=!pda_sh_st,tag=aj.pda.root] at @s positioned ^ ^ ^3 as @e[tag=leave_bullet,limit=1,sort=nearest] at @s if entity @a[distance=..1.7,limit=1,sort=nearest] run particle minecraft:dust 0.855 0.012 0.529 1 ~ ~ ~ 0.5 .5 .5 3 20 normal
execute as @e[tag=!pda_sh_st,tag=aj.pda.root] at @s positioned ^ ^ ^3 as @e[tag=leave_bullet,limit=1,sort=nearest] at @s if entity @a[distance=..1.7,limit=1,sort=nearest] run playsound minecraft:block.cherry_leaves.step neutral @a[distance=..10] ~ ~ ~ 5 0.7
execute as @e[tag=!pda_sh_st,tag=aj.pda.root] at @s positioned ^ ^ ^3 as @e[tag=leave_bullet,limit=1,sort=nearest] at @s if entity @a[distance=..1.7,limit=1,sort=nearest] run kill @s
execute as @e[tag=!pda_sh_st,tag=aj.pda.root] at @s positioned ^ ^ ^3 as @e[tag=leave_bullet,limit=1,sort=nearest] at @s unless block ^ ^ ^0.5 air run tag @e[limit=1,sort=nearest,tag=aj.pda.root] add pda_do_no
execute as @e[tag=!pda_sh_st,tag=aj.pda.root] at @s positioned ^ ^ ^3 as @e[tag=leave_bullet,limit=1,sort=nearest] at @s unless block ^ ^ ^0.5 air run particle minecraft:dust 0.855 0.012 0.529 1 ~ ~ ~ 0.5 .5 .5 3 20 normal
execute as @e[tag=!pda_sh_st,tag=aj.pda.root] at @s positioned ^ ^ ^3 as @e[tag=leave_bullet,limit=1,sort=nearest] at @s unless block ^ ^ ^0.5 air run playsound minecraft:block.cherry_leaves.step neutral @a[distance=..10] ~ ~ ~ 5 0.7
execute as @e[tag=!pda_sh_st,tag=aj.pda.root] at @s positioned ^ ^ ^3 as @e[tag=leave_bullet,limit=1,sort=nearest] at @s unless block ^ ^ ^0.5 air run kill @s


execute if entity @s[tag=pda_sh_st] run schedule function dragon:attacks/shoot 10t

tag @e[tag=pda_sh_sl] remove pda_sh_sl

execute as @e[tag=!pda_sh_st,tag=aj.pda.root,tag=!pda_do_no] run schedule function dragon:attacks/shoot 1t replace

tag @e[tag=pda_sh_st] add pda_sh_sl
tag @e[tag=pda_sh_st] remove pda_sh_st


