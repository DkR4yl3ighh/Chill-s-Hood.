execute if entity @s[tag=pda_s_st] run function pda:animations/slash/play
execute if entity @s[tag=pda_s_st] run schedule function dragon:attacks/slash 1s replace
tag @s add pda_r
execute as @e[tag=!pda_s_st,tag=aj.pda.root] at @s positioned ^ ^ ^-2 as @a[distance=..4] run function dragon:attacks/cherry_dmg/slash_dmg
execute as @e[tag=!pda_s_st,tag=aj.pda.root] at @s positioned ^ ^ ^-2 as @a[distance=..4] run scoreboard players add @s cherry_effect 80
tag @e[tag=!pda_s_st,tag=aj.pda.root,tag=aj.pda.animation.slash] add pda_do_no
tag @e[tag=!pda_s_st,tag=aj.pda.root,tag=aj.pda.animation.slash] remove pda_r
tag @s remove pda_s_st