tag @s remove pda_do_no
tag @s remove default

execute as @s at @s run function pda:animations/default/stop

#pda_{attack name in short}_st(start)
#the drops are summoned from every attack so everything is at least possible

summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_sh",",standard_a","pda_attack"]},Count:1},PickupDelay:255}
summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_lg",",standard_a","pda_attack"]},Count:1},PickupDelay:255}
summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_ll",",standard_a","pda_attack"]},Count:1},PickupDelay:255}
summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_s","standard_a","pda_attack"]},Count:1},PickupDelay:255}
summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_d","standard_a","pda_attack"]},Count:1},PickupDelay:255}
summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_p","standard_a","pda_attack"]},Count:1},PickupDelay:255}

#here are the extra drops depending on the position
#pda_attack to recognize it as a drop from the pink dragon
#p_ax to make it not stack
#p_{attack in short} to recognize the result

#Piston push
execute if entity @a[distance=..2] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a1","p_p","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=..2] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a2","p_p","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=..3] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a3","p_p","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=..4] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a4","p_p","pda_attack"]},Count:1},PickupDelay:255}

#Slash
execute if entity @a[distance=..1] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a1","p_s","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=..1] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a2","p_s","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=..2] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a3","p_s","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=..3] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a4","p_s","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=..3] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a5","p_s","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=..3] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a6","p_s","pda_attack"]},Count:1},PickupDelay:255}
execute unless entity @a[distance=..4.5] run kill @e[limit=1,sort=nearest,nbt={Item:{tag:{Tags:["p_s"]}}}]

#shoot
execute if entity @a[distance=10..20] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a1","p_sh","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=10..20] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a2","p_sh","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=15..25] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a3","p_sh","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=5..10] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a4","p_sh","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=25..40] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a5","p_sh","pda_attack"]},Count:1},PickupDelay:255}

#leave grenade
execute if entity @a[distance=7.5..10] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a1","p_lg","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=7.5..12.5] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a2","p_lg","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=7.5..17.5] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a3","p_lg","pda_attack"]},Count:1},PickupDelay:255}

#dash
execute if entity @a[distance=5..10] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a1","p_d","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=9..15] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a2","p_d","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=12.5..20] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a3","p_d","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=15..25] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a4","p_d","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=15..25] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a5","p_d","pda_attack"]},Count:1},PickupDelay:255}

#leave lope
execute if entity @a[distance=10..15] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a1","p_ll","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=15..22.5] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a2","p_ll","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=15..22.5] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a3","p_ll","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=17.5..30] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a4","p_ll","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=17.5..30] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a5","p_ll","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=17.5..30] run summon item ~ ~ ~ {Item:{id:cherry_planks,tag:{Tags:["p_a6","p_ll","pda_attack"]},Count:1},PickupDelay:255}
execute if entity @a[distance=..5] run kill @e[limit=1,sort=nearest,nbt={Item:{tag:{Tags:["p_ll"]}}}]

#tag a random item
#c for chosen and a for attack
execute as @e[sort=random,limit=1,distance=..5,nbt={Item:{tag:{Tags:["pda_attack"]}}}] run tag @s add pda_c_a

#the execution depending on the randoms items tag
execute as @e[sort=nearest,limit=1,distance=..5,tag=pda_c_a] if entity @s[nbt={Item:{tag:{Tags:["p_sh"]}}}] at @s as @e[limit=1,sort=nearest,tag=aj.pda.root] at @s run tag @s add pda_sh_st
execute as @e[sort=nearest,limit=1,distance=..5,tag=pda_c_a] if entity @s[nbt={Item:{tag:{Tags:["p_sh"]}}}] at @s as @e[limit=1,sort=nearest,tag=aj.pda.root] at @s run function dragon:attacks/shoot

execute as @e[sort=nearest,limit=1,distance=..5,tag=pda_c_a] if entity @s[nbt={Item:{tag:{Tags:["p_lg"]}}}] at @s as @e[limit=1,sort=nearest,tag=aj.pda.root] at @s run tag @s add pda_lg_st
execute as @e[sort=nearest,limit=1,distance=..5,tag=pda_c_a] if entity @s[nbt={Item:{tag:{Tags:["p_lg"]}}}] at @s as @e[limit=1,sort=nearest,tag=aj.pda.root] at @s run function dragon:attacks/leave_granate

execute as @e[sort=nearest,limit=1,distance=..5,tag=pda_c_a] if entity @s[nbt={Item:{tag:{Tags:["p_ll"]}}}] at @s as @e[limit=1,sort=nearest,tag=aj.pda.root] at @s run tag @s add pda_ll_st
execute as @e[sort=nearest,limit=1,distance=..5,tag=pda_c_a] if entity @s[nbt={Item:{tag:{Tags:["p_ll"]}}}] at @s as @e[limit=1,sort=nearest,tag=aj.pda.root] at @s run function dragon:attacks/leave_lope

execute as @e[sort=nearest,limit=1,distance=..5,tag=pda_c_a] if entity @s[nbt={Item:{tag:{Tags:["p_s"]}}}] at @s as @e[limit=1,sort=nearest,tag=aj.pda.root] at @s run tag @s add pda_s_st
execute as @e[sort=nearest,limit=1,distance=..5,tag=pda_c_a] if entity @s[nbt={Item:{tag:{Tags:["p_s"]}}}] at @s as @e[limit=1,sort=nearest,tag=aj.pda.root] at @s run function dragon:attacks/slash

execute as @e[sort=nearest,limit=1,distance=..5,tag=pda_c_a] if entity @s[nbt={Item:{tag:{Tags:["p_d"]}}}] at @s as @e[limit=1,sort=nearest,tag=aj.pda.root] at @s run tag @s add pda_d_st
execute as @e[sort=nearest,limit=1,distance=..5,tag=pda_c_a] if entity @s[nbt={Item:{tag:{Tags:["p_d"]}}}] at @s as @e[limit=1,sort=nearest,tag=aj.pda.root] at @s run function dragon:attacks/dash

execute as @e[sort=nearest,limit=1,distance=..5,tag=pda_c_a] if entity @s[nbt={Item:{tag:{Tags:["p_p"]}}}] at @s as @e[limit=1,sort=nearest,tag=aj.pda.root] at @s run tag @s add pda_p_st
execute as @e[sort=nearest,limit=1,distance=..5,tag=pda_c_a] if entity @s[nbt={Item:{tag:{Tags:["p_p"]}}}] at @s as @e[limit=1,sort=nearest,tag=aj.pda.root] at @s run function dragon:attacks/piston_push

#then delete it
kill @e[nbt={Item:{tag:{Tags:[pda_attack]}}},distance=..5]