                                                                                                                                                                                                                                    #{Id:14,Duration:-1,ShowParticles:0b},
execute as @e[type=item_display,tag=summon_boss,tag=!fight_active,tag=not_defeat] at @s if entity @a[distance=..7.5,gamemode=!creative,gamemode=!spectator] run summon ravager ~ ~ ~ {NoAI:1b,Tags:[dragon_team,dragon_box],Silent:1b,ActiveEffects:[{Id:14,Duration:-1,ShowParticles:0b},{Id:6,Duration:1,Amplifier:120,ShowParticles:0b}],Attributes:[{Name:"generic.max_health",Base:1200f}]}
execute as @e[type=item_display,tag=summon_boss,tag=!fight_active,tag=not_defeat] at @s if entity @a[distance=..7.5,gamemode=!creative,gamemode=!spectator] positioned ~ ~1 ~ run function pda:summon
execute as @e[type=item_display,tag=summon_boss,tag=!fight_active,tag=not_defeat] at @s if entity @a[distance=..7.5,gamemode=!creative,gamemode=!spectator] positioned ~ ~1 ~ run tag @e[limit=1,sort=nearest,tag=aj.pda.root] add pda_sum

#close door
execute as @e[type=item_display,tag=summon_boss,tag=!fight_active,tag=not_defeat] at @s if entity @a[distance=..7.5,gamemode=!creative,gamemode=!spectator] run fill ^3 ^-2 ^8 ^7 ^-2 ^9 cherry_planks
execute as @e[type=item_display,tag=summon_boss,tag=!fight_active,tag=not_defeat] at @s if entity @a[distance=..7.5,gamemode=!creative,gamemode=!spectator] run fill ^3 ^-3 ^8 ^7 ^-3 ^9 crimson_planks

tag @e[tag=aj.pda.root,tag=pda_sum] add pda_do_no
execute as @e[type=item_display,tag=summon_boss,tag=!fight_active,tag=not_defeat] at @s if entity @a[distance=..7.5,gamemode=!creative,gamemode=!spectator] positioned ~ ~1 ~ run particle minecraft:item cherry_leaves ~ ~ ~ 4 4 4 1 512 normal

execute as @e[type=item_display,tag=summon_boss,tag=!fight_active,tag=not_defeat] at @s if entity @a[distance=..7.5,gamemode=!creative,gamemode=!spectator] at @s run bossbar set minecraft:pink_dragon players @a[distance=..25]
bossbar add pink_dragon "Pink Dragon"
bossbar set minecraft:pink_dragon color pink
bossbar set minecraft:pink_dragon max 1200
execute store result bossbar minecraft:pink_dragon value run data get entity @e[limit=1,sort=nearest,tag=dragon_box] Health
execute as @e[tag=aj.pda.root] at @s unless entity @e[distance=..2,tag=dragon_box] run function dragon:others/boss_defeated

team add cherry_Dragon_Team
team join cherry_Dragon_Team @e[tag=dragon_team]
team modify cherry_Dragon_Team collisionRule never

execute as @e[type=item_display,tag=summon_boss,tag=!fight_active,tag=not_defeat] at @s if entity @a[distance=..7.5,gamemode=!creative,gamemode=!spectator] run tag @s add fight_active
tag @e[tag=aj.pda.root,tag=pda_sum] remove pda_sum
schedule function dragon:others/summon_boss 1s replace