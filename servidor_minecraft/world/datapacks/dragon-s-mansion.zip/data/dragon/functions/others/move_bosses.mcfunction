#execute as @e[tag=aj.pda.root,tag=pda_do_no] at @s at @e[tag=dragon_box,limit=1,sort=nearest] run tp @s ~ ~0.9 ~ ~180 0
execute as @e[tag=aj.pda.root,tag=pda_do_no] at @s as @e[tag=dragon_box,limit=1,sort=nearest] at @s facing entity @p eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=aj.pda.root,tag=pda_r] at @s as @e[tag=dragon_box,limit=1,sort=nearest] at @s facing entity @p eyes run tp @s ~ ~ ~ ~ ~
#execute as @e[tag=aj.pda.root,tag=default,tag=pda_do_no] run function pda:animations/default/play
tag @e[tag=aj.pda.root,tag=!default,tag=pda_do_no] add default
#other rotations
execute as @e[tag=aj.pda.root,tag=pda_r] at @s at @e[tag=dragon_box,limit=1,sort=nearest] run tp @s ~ ~0.9 ~ ~180 0
execute as @e[tag=aj.pda.root,tag=pda_t] at @s at @e[tag=dragon_box,limit=1,sort=nearest] run tp @s ~ ~0.9 ~ ~180 ~