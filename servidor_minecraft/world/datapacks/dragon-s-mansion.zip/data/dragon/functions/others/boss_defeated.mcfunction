bossbar remove pink_dragon
function pda:remove/this
particle minecraft:item redstone ~ ~ ~ 4 4 4 1 4096 normal
particle minecraft:item cherry_leaves ~ ~ ~ 4 4 4 1 4096 normal
particle minecraft:item cherry_planks ~ ~ ~ 4 4 4 1 4096 normal
playsound minecraft:entity.ender_dragon.ambient hostile @a[distance=..25] ~ ~ ~ 4 2 1
playsound minecraft:entity.ravager.death hostile @a[distance=..25] ~ ~ ~ 4 2 1
summon item ~ ~ ~ {PickupDelay:60,Item:{id:"minecraft:iron_sword",Count:1b,tag:{CustomModelData:23241,AttributeModifiers:[{AttributeName:"generic.attack_damage",Amount:6.5,Slot:mainhand,Name:"generic.attack_damage",UUID:[I;-12358,13689,10226,-27378]},{AttributeName:"generic.attack_speed",Amount:-2.8,Slot:mainhand,Name:"generic.attack_speed",UUID:[I;-12358,13789,10226,-27578]}],display:{Name:'[{"text":"Cherrytana","italic":false,"color":"light_purple"}]'},Enchantments:[{id:sweeping,lvl:5}],HideFlags:2}}}

#open door
execute at @e[type=item_display,tag=summon_boss,tag=fight_active,tag=not_defeat,limit=1,sort=nearest] run fill ^3 ^-2 ^8 ^7 ^-3 ^9 air
execute at @e[type=item_display,tag=summon_boss,tag=fight_active,tag=not_defeat,limit=1,sort=nearest] run fill ^6 ^-3 ^8 ^6 ^-3 ^9 crimson_slab
execute at @e[type=item_display,tag=summon_boss,tag=fight_active,tag=not_defeat,limit=1,sort=nearest] run fill ^7 ^-3 ^8 ^7 ^-3 ^9 crimson_planks
execute at @e[type=item_display,tag=summon_boss,tag=fight_active,tag=not_defeat,limit=1,sort=nearest] run fill ^7 ^-2 ^8 ^7 ^-2 ^9 cherry_slab

tag @e[limit=1,sort=nearest,tag=fight_active,tag=summon_boss] remove not_defeat
tag @e[limit=1,sort=nearest,tag=fight_active,tag=summon_boss] remove fight_active