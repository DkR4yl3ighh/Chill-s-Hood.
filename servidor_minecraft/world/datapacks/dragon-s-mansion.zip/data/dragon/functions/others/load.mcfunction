scoreboard objectives add cherry_death deathCount "Reset Cherry effect"
scoreboard objectives add cherry_effect dummy "Cherry effect"
scoreboard objectives add cherries_SI dummy "Selected Item Cherries"
scoreboard objectives add golden_cherries_SI dummy "Selected Item Golden Cherries"
scoreboard objectives add ate_cherries minecraft.used:minecraft.apple
scoreboard objectives add ate_golden_cherries minecraft.used:minecraft.apple
scoreboard objectives add cherrytana_hit minecraft.used:minecraft.iron_sword "Cherrytana Hit"
scoreboard objectives add pda_attack dummy "Cooldown"
tellraw @a ["",{"text":"/","obfuscated":true,"color":"dark_purple","hoverEvent":{"action":"show_text","contents":"Coded and textured by Vamen :D"}},{"text":"Pink Dragon Datapack","color":"light_purple","hoverEvent":{"action":"show_text","contents":"Coded and textured by Vamen :D"}},{"text":"\\","obfuscated":true,"color":"dark_purple","hoverEvent":{"action":"show_text","contents":"Coded and textured by Vamen :D"}},{"text":" ","hoverEvent":{"action":"show_text","contents":"Coded and textured by Vamen :D"}},{"text":"loaded","color":"yellow","hoverEvent":{"action":"show_text","contents":"Coded and textured by Vamen :D"}}]