execute if score @s aj.pda.animation.fly.loop_mode = $aj.loop_mode.loop aj.i run function zzz_pda_internal:animations/fly/end_loop
execute if score @s aj.pda.animation.fly.loop_mode = $aj.loop_mode.once aj.i run function pda:animations/fly/stop
execute if score @s aj.pda.animation.fly.loop_mode = $aj.loop_mode.hold aj.i run function pda:animations/fly/pause