scoreboard players set @s aj.anim_time 0
scoreboard players set @s aj.pda.animation.leave_grenate.local_anim_time 0
scoreboard players set @s aj.pda.animation.leave_grenate.loop_mode 1
execute on passengers run data modify entity @s interpolation_duration set value 0
function zzz_pda_internal:animations/leave_grenate/tree/leaf_0
execute on passengers run data modify entity @s interpolation_duration set value 1
tag @s add aj.pda.animation.leave_grenate