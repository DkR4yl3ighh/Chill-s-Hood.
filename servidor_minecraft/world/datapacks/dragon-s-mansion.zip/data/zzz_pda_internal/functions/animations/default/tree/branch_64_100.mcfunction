execute if score @s aj.anim_time matches 64..71 run function zzz_pda_internal:animations/default/tree/branch_64_71
execute if score @s aj.anim_time matches 72..79 run function zzz_pda_internal:animations/default/tree/branch_72_79
execute if score @s aj.anim_time matches 80..87 run function zzz_pda_internal:animations/default/tree/branch_80_87
execute if score @s aj.anim_time matches 88..95 run function zzz_pda_internal:animations/default/tree/branch_88_95
execute if score @s aj.anim_time matches 96..100 run function zzz_pda_internal:animations/default/tree/branch_96_100