scoreboard players set @s aj.pda.animation.fly.local_anim_time 0
scoreboard players set @s aj.anim_time 0
function zzz_pda_internal:animations/fly/tree/leaf_0