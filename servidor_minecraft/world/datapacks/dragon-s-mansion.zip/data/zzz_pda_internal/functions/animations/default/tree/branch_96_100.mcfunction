execute if score @s aj.anim_time matches 96 run function zzz_pda_internal:animations/default/tree/leaf_96
execute if score @s aj.anim_time matches 97 run function zzz_pda_internal:animations/default/tree/leaf_97
execute if score @s aj.anim_time matches 98 run function zzz_pda_internal:animations/default/tree/leaf_98
execute if score @s aj.anim_time matches 99 run function zzz_pda_internal:animations/default/tree/leaf_99
execute if score @s aj.anim_time matches 100 run function zzz_pda_internal:animations/default/tree/leaf_100