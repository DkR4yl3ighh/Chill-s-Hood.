execute if score @s aj.anim_time matches 0..7 run function zzz_pda_internal:animations/leave_grenate/tree/branch_0_7
execute if score @s aj.anim_time matches 8..15 run function zzz_pda_internal:animations/leave_grenate/tree/branch_8_15
execute if score @s aj.anim_time matches 16..23 run function zzz_pda_internal:animations/leave_grenate/tree/branch_16_23
execute if score @s aj.anim_time matches 24..31 run function zzz_pda_internal:animations/leave_grenate/tree/branch_24_31
execute if score @s aj.anim_time matches 32..39 run function zzz_pda_internal:animations/leave_grenate/tree/branch_32_39
execute if score @s aj.anim_time matches 40..47 run function zzz_pda_internal:animations/leave_grenate/tree/branch_40_47
execute if score @s aj.anim_time matches 48..54 run function zzz_pda_internal:animations/leave_grenate/tree/branch_48_54