scoreboard players set @s aj.pda.animation.fly.local_anim_time 0
tag @s remove aj.pda.animation.fly
execute on passengers run data modify entity @s interpolation_duration set value 0
tag @s add aj.pda.disable_command_keyframes
function zzz_pda_internal:animations/fly/tree/leaf_0
tag @s remove aj.pda.disable_command_keyframes