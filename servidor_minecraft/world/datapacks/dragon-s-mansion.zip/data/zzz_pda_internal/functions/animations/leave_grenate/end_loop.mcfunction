scoreboard players set @s aj.pda.animation.leave_grenate.local_anim_time 0
scoreboard players set @s aj.anim_time 0
function zzz_pda_internal:animations/leave_grenate/tree/leaf_0