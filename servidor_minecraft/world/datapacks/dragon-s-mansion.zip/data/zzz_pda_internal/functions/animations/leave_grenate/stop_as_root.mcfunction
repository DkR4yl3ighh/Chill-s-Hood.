scoreboard players set @s aj.pda.animation.leave_grenate.local_anim_time 0
tag @s remove aj.pda.animation.leave_grenate
execute on passengers run data modify entity @s interpolation_duration set value 0
tag @s add aj.pda.disable_command_keyframes
function zzz_pda_internal:animations/leave_grenate/tree/leaf_0
tag @s remove aj.pda.disable_command_keyframes