execute if score @s aj.anim_time matches 64 run function zzz_pda_internal:animations/default/tree/leaf_64
execute if score @s aj.anim_time matches 65 run function zzz_pda_internal:animations/default/tree/leaf_65
execute if score @s aj.anim_time matches 66 run function zzz_pda_internal:animations/default/tree/leaf_66
execute if score @s aj.anim_time matches 67 run function zzz_pda_internal:animations/default/tree/leaf_67
execute if score @s aj.anim_time matches 68 run function zzz_pda_internal:animations/default/tree/leaf_68
execute if score @s aj.anim_time matches 69 run function zzz_pda_internal:animations/default/tree/leaf_69
execute if score @s aj.anim_time matches 70 run function zzz_pda_internal:animations/default/tree/leaf_70
execute if score @s aj.anim_time matches 71 run function zzz_pda_internal:animations/default/tree/leaf_71