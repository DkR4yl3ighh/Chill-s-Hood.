execute if score @s aj.anim_time matches 0..7 run function zzz_pda_internal:animations/fly/tree/branch_0_7
execute if score @s aj.anim_time matches 8..15 run function zzz_pda_internal:animations/fly/tree/branch_8_15
execute if score @s aj.anim_time matches 16 run function zzz_pda_internal:animations/fly/tree/leaf_16
execute if score @s aj.anim_time matches 17 run function zzz_pda_internal:animations/fly/tree/leaf_17
execute if score @s aj.anim_time matches 18 run function zzz_pda_internal:animations/fly/tree/leaf_18
execute if score @s aj.anim_time matches 19 run function zzz_pda_internal:animations/fly/tree/leaf_19