scoreboard players set @s aj.anim_time 0
scoreboard players set @s aj.pda.animation.fly.local_anim_time 0
scoreboard players set @s aj.pda.animation.fly.loop_mode 0
execute on passengers run data modify entity @s interpolation_duration set value 0
function zzz_pda_internal:animations/fly/tree/leaf_0
execute on passengers run data modify entity @s interpolation_duration set value 1
tag @s add aj.pda.animation.fly