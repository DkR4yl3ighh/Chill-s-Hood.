scoreboard players set @s aj.anim_time 0
scoreboard players set @s aj.pda.animation.default.local_anim_time 0
scoreboard players set @s aj.pda.animation.default.loop_mode 0
execute on passengers run data modify entity @s interpolation_duration set value 0
function zzz_pda_internal:animations/default/tree/leaf_0
execute on passengers run data modify entity @s interpolation_duration set value 1
tag @s add aj.pda.animation.default