execute if score @s aj.anim_time matches 0 run function zzz_pda_internal:animations/fly/tree/leaf_0
execute if score @s aj.anim_time matches 1 run function zzz_pda_internal:animations/fly/tree/leaf_1
execute if score @s aj.anim_time matches 2 run function zzz_pda_internal:animations/fly/tree/leaf_2
execute if score @s aj.anim_time matches 3 run function zzz_pda_internal:animations/fly/tree/leaf_3
execute if score @s aj.anim_time matches 4 run function zzz_pda_internal:animations/fly/tree/leaf_4
execute if score @s aj.anim_time matches 5 run function zzz_pda_internal:animations/fly/tree/leaf_5
execute if score @s aj.anim_time matches 6 run function zzz_pda_internal:animations/fly/tree/leaf_6
execute if score @s aj.anim_time matches 7 run function zzz_pda_internal:animations/fly/tree/leaf_7