execute if score @s aj.anim_time matches 48 run function zzz_pda_internal:animations/default/tree/leaf_48
execute if score @s aj.anim_time matches 49 run function zzz_pda_internal:animations/default/tree/leaf_49
execute if score @s aj.anim_time matches 50 run function zzz_pda_internal:animations/default/tree/leaf_50
execute if score @s aj.anim_time matches 51 run function zzz_pda_internal:animations/default/tree/leaf_51
execute if score @s aj.anim_time matches 52 run function zzz_pda_internal:animations/default/tree/leaf_52
execute if score @s aj.anim_time matches 53 run function zzz_pda_internal:animations/default/tree/leaf_53
execute if score @s aj.anim_time matches 54 run function zzz_pda_internal:animations/default/tree/leaf_54
execute if score @s aj.anim_time matches 55 run function zzz_pda_internal:animations/default/tree/leaf_55