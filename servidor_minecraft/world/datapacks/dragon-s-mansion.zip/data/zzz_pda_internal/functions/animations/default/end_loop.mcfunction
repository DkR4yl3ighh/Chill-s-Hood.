scoreboard players set @s aj.pda.animation.default.local_anim_time 0
scoreboard players set @s aj.anim_time 0
function zzz_pda_internal:animations/default/tree/leaf_0