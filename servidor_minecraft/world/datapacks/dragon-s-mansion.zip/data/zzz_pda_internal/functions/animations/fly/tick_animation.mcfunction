scoreboard players add @s aj.pda.animation.fly.local_anim_time 1
scoreboard players operation @s aj.anim_time = @s aj.pda.animation.fly.local_anim_time
function zzz_pda_internal:animations/fly/apply_frame_as_root
execute if score @s aj.pda.animation.fly.local_anim_time matches 19.. run function zzz_pda_internal:animations/fly/end