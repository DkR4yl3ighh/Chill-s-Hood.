scoreboard players set @s aj.pda.animation.default.loop_mode 0
execute on passengers run data modify entity @s interpolation_duration set value 1
tag @s add aj.pda.animation.default