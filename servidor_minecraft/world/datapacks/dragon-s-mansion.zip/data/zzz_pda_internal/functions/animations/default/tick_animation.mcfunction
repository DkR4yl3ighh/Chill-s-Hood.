scoreboard players add @s aj.pda.animation.default.local_anim_time 1
scoreboard players operation @s aj.anim_time = @s aj.pda.animation.default.local_anim_time
function zzz_pda_internal:animations/default/apply_frame_as_root
execute if score @s aj.pda.animation.default.local_anim_time matches 100.. run function zzz_pda_internal:animations/default/end