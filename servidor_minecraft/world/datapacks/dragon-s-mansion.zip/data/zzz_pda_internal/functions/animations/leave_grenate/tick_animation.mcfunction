scoreboard players add @s aj.pda.animation.leave_grenate.local_anim_time 1
scoreboard players operation @s aj.anim_time = @s aj.pda.animation.leave_grenate.local_anim_time
function zzz_pda_internal:animations/leave_grenate/apply_frame_as_root
execute if score @s aj.pda.animation.leave_grenate.local_anim_time matches 54.. run function zzz_pda_internal:animations/leave_grenate/end