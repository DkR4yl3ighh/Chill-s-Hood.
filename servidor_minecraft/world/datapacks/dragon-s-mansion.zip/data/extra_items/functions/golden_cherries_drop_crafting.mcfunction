execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:gold_ingot",Count:4b}}] at @s if block ~ ~-1 ~ crafting_table run tag @s add craft_gold_ingot_1
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:apple",Count:1b,tag:{CustomModelData:23241}}}] at @s if block ~ ~-1 ~ crafting_table run tag @s add craft_apple_2
execute at @e[type=item,tag=craft_gold_ingot_1] as @e[type=item,tag=craft_apple_2,distance=..1] run summon item ~ ~ ~ {Tags:["itemkill1"],PickupDelay:20,Item:{id:"minecraft:apple",Count:1b,tag:{CustomModelData:23242,display:{Name:'[{"text":"Golden Cherries","italic":false,"color":"aqua"}]'}}}}
execute at @e[type=item,tag=craft_gold_ingot_1] as @e[type=item,tag=craft_apple_2,distance=..1] run particle minecraft:item gold_block ~ ~.4 ~ .2 .2 .2 0 15
execute at @e[type=item,tag=craft_gold_ingot_1] as @e[type=item,tag=craft_apple_2,distance=..1] run playsound minecraft:item.axe.scrape neutral @a[distance=..7] ~ ~ ~ 5 1
execute at @e[type=item,tag=itemkill1] run kill @e[type=item,tag=craft_gold_ingot_1,distance=..1]
execute at @e[type=item,tag=itemkill1] run kill @e[type=item,tag=craft_apple_2,distance=..1]
tag @e[type=item] remove itemkill1

schedule function extra_items:golden_cherries_drop_crafting 10t replace 