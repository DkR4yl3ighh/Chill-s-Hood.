execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:apple",Count:4b,tag:{CustomModelData:23242}}}] at @s if block ~ ~-1 ~ crafting_table run tag @s add craft_golden_cherry_cb_1
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:cherry_leaves",Count:4b}}] at @s if block ~ ~-1 ~ crafting_table run tag @s add craft_cherry_leaves_cb_2
execute as @e[limit=1,type=item,nbt={OnGround:1b,Item:{id:"minecraft:pink_dye",Count:1b,tag:{CustomModelData:23241}}}] at @s if block ~ ~-1 ~ crafting_table run tag @s add craft_cherry_blossom_dupe_3
execute at @e[type=item,tag=craft_golden_cherry_cb_1] at @e[type=item,tag=craft_cherry_leaves_cb_2] as @e[type=item,tag=craft_cherry_blossom_dupe_3,distance=..1] run summon item ~ ~ ~ {Tags:["itemkill1"],PickupDelay:20,Item:{id:"minecraft:pink_dye",Count:2b,tag:{CustomModelData:23241,display:{Name:'[{"text":"Cherry Blossom","italic":false}]'}}}}
execute at @e[type=item,tag=craft_golden_cherry_cb_1] at @e[type=item,tag=craft_cherry_leaves_cb_2] as @e[type=item,tag=craft_cherry_blossom_dupe_3,distance=..1] run particle minecraft:item cherry_leaves ~ ~.4 ~ .2 .2 .2 0 15
execute at @e[type=item,tag=craft_golden_cherry_cb_1] at @e[type=item,tag=craft_cherry_leaves_cb_2] as @e[type=item,tag=craft_cherry_blossom_dupe_3,distance=..1] run playsound minecraft:item.axe.scrape neutral @a[distance=..7] ~ ~ ~ 5 1
execute at @e[type=item,tag=itemkill1] run kill @e[type=item,tag=craft_golden_cherry_cb_1,distance=..1]
execute at @e[type=item,tag=itemkill1] run kill @e[type=item,tag=craft_cherry_leaves_cb_2,distance=..1]
execute at @e[type=item,tag=itemkill1] run kill @e[type=item,tag=craft_cherry_blossom_dupe_3,distance=..1]
tag @e[type=item] remove itemkill1

schedule function extra_items:cherry_blossom_duplication_drop_crafting 10t replace 