execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:brick",Count:1b,tag:{CustomModelData:23241}}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_dragon_temlate_1

#tag trims
#normal
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:amethyst_shard",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_ingredients_2
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:copper_ingot",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_ingredients_2
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:diamond",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_ingredients_2
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:emerald",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_ingredients_2
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:gold_ingot",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_ingredients_2
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:iron_ingot",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_ingredients_2
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:lapis_lazuli",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_ingredients_2
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:quartz",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_ingredients_2
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:netherite_ingot",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_ingredients_2
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:redstone",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_ingredients_2
#custom
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:pink_dye",Count:1b,tag:{CustomModelData:23241}}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_ingredients_2

#helmets
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:leather_helmet",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:chainmail_helmet",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:golden_helmet",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:iron_helmet",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:diamond_helmet",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:netherite_helmet",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:turtle_helmet",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3

#chestplates
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:leather_chestplate",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:chainmail_chestplate",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:golden_chestplate",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:iron_chestplate",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:diamond_chestplate",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:netherite_chestplate",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3

#leggings
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:leather_leggings",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:chainmail_leggings",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:golden_leggings",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:iron_leggings",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:diamond_leggings",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:netherite_leggings",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3

#boots
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:leather_boots",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:chainmail_boots",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:golden_boots",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:iron_boots",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:diamond_boots",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3
execute as @e[type=item,nbt={OnGround:1b,Item:{id:"minecraft:netherite_boots",Count:1b}}] at @s if block ~ ~-1 ~ smithing_table run tag @s add craft_armor_piece_3


execute at @e[type=item,tag=craft_dragon_temlate_1] at @e[type=item,tag=craft_ingredients_2,distance=..0.5,limit=1] as @e[type=item,tag=craft_armor_piece_3,distance=..0.5,limit=1,sort=nearest] if entity @e[distance=..0.5,type=item,tag=craft_ingredients_2,nbt={OnGround:1b,Item:{id:"minecraft:amethyst_shard",Count:1b}}] run data merge entity @s {PickupDelay:20,Item:{tag:{Trim:{material:"minecraft:amethyst",pattern:"dragon_template:dragon"}}}}
execute at @e[type=item,tag=craft_dragon_temlate_1] at @e[type=item,tag=craft_ingredients_2,distance=..0.5,limit=1] as @e[type=item,tag=craft_armor_piece_3,distance=..0.5,limit=1,sort=nearest] if entity @e[distance=..0.5,type=item,tag=craft_ingredients_2,nbt={OnGround:1b,Item:{id:"minecraft:copper_ingot",Count:1b}}] run data merge entity @s {PickupDelay:20,Item:{tag:{Trim:{material:"minecraft:copper_ingot",pattern:"dragon_template:dragon"}}}}
execute at @e[type=item,tag=craft_dragon_temlate_1] at @e[type=item,tag=craft_ingredients_2,distance=..0.5,limit=1] as @e[type=item,tag=craft_armor_piece_3,distance=..0.5,limit=1,sort=nearest] if entity @e[distance=..0.5,type=item,tag=craft_ingredients_2,nbt={OnGround:1b,Item:{id:"minecraft:diamond",Count:1b}}] run data merge entity @s {PickupDelay:20,Item:{tag:{Trim:{material:"minecraft:diamond",pattern:"dragon_template:dragon"}}}}
execute at @e[type=item,tag=craft_dragon_temlate_1] at @e[type=item,tag=craft_ingredients_2,distance=..0.5,limit=1] as @e[type=item,tag=craft_armor_piece_3,distance=..0.5,limit=1,sort=nearest] if entity @e[distance=..0.5,type=item,tag=craft_ingredients_2,nbt={OnGround:1b,Item:{id:"minecraft:emerald",Count:1b}}] run data merge entity @s {PickupDelay:20,Item:{tag:{Trim:{material:"minecraft:emerald",pattern:"dragon_template:dragon"}}}}
execute at @e[type=item,tag=craft_dragon_temlate_1] at @e[type=item,tag=craft_ingredients_2,distance=..0.5,limit=1] as @e[type=item,tag=craft_armor_piece_3,distance=..0.5,limit=1,sort=nearest] if entity @e[distance=..0.5,type=item,tag=craft_ingredients_2,nbt={OnGround:1b,Item:{id:"minecraft:gold_ingot",Count:1b}}] run data merge entity @s {PickupDelay:20,Item:{tag:{Trim:{material:"minecraft:gold",pattern:"dragon_template:dragon"}}}}
execute at @e[type=item,tag=craft_dragon_temlate_1] at @e[type=item,tag=craft_ingredients_2,distance=..0.5,limit=1] as @e[type=item,tag=craft_armor_piece_3,distance=..0.5,limit=1,sort=nearest] if entity @e[distance=..0.5,type=item,tag=craft_ingredients_2,nbt={OnGround:1b,Item:{id:"minecraft:iron_ingot",Count:1b}}] run data merge entity @s {PickupDelay:20,Item:{tag:{Trim:{material:"minecraft:iron",pattern:"dragon_template:dragon"}}}}
execute at @e[type=item,tag=craft_dragon_temlate_1] at @e[type=item,tag=craft_ingredients_2,distance=..0.5,limit=1] as @e[type=item,tag=craft_armor_piece_3,distance=..0.5,limit=1,sort=nearest] if entity @e[distance=..0.5,type=item,tag=craft_ingredients_2,nbt={OnGround:1b,Item:{id:"minecraft:lapis_lazuli",Count:1b}}] run data merge entity @s {PickupDelay:20,Item:{tag:{Trim:{material:"minecraft:lapis",pattern:"dragon_template:dragon"}}}}
execute at @e[type=item,tag=craft_dragon_temlate_1] at @e[type=item,tag=craft_ingredients_2,distance=..0.5,limit=1] as @e[type=item,tag=craft_armor_piece_3,distance=..0.5,limit=1,sort=nearest] if entity @e[distance=..0.5,type=item,tag=craft_ingredients_2,nbt={OnGround:1b,Item:{id:"minecraft:quartz",Count:1b}}] run data merge entity @s {PickupDelay:20,Item:{tag:{Trim:{material:"minecraft:quartz",pattern:"dragon_template:dragon"}}}}
execute at @e[type=item,tag=craft_dragon_temlate_1] at @e[type=item,tag=craft_ingredients_2,distance=..0.5,limit=1] as @e[type=item,tag=craft_armor_piece_3,distance=..0.5,limit=1,sort=nearest] if entity @e[distance=..0.5,type=item,tag=craft_ingredients_2,nbt={OnGround:1b,Item:{id:"minecraft:netherite_ingot",Count:1b}}] run data merge entity @s {PickupDelay:20,Item:{tag:{Trim:{material:"minecraft:netherite",pattern:"dragon_template:dragon"}}}}
execute at @e[type=item,tag=craft_dragon_temlate_1] at @e[type=item,tag=craft_ingredients_2,distance=..0.5,limit=1] as @e[type=item,tag=craft_armor_piece_3,distance=..0.5,limit=1,sort=nearest] if entity @e[distance=..0.5,type=item,tag=craft_ingredients_2,nbt={OnGround:1b,Item:{id:"minecraft:redstone",Count:1b}}] run data merge entity @s {PickupDelay:20,Item:{tag:{Trim:{material:"minecraft:redstone",pattern:"dragon_template:dragon"}}}}
execute at @e[type=item,tag=craft_dragon_temlate_1] at @e[type=item,tag=craft_ingredients_2,distance=..0.5,limit=1] as @e[type=item,tag=craft_armor_piece_3,distance=..0.5,limit=1,sort=nearest] if entity @e[distance=..0.5,type=item,tag=craft_ingredients_2,nbt={OnGround:1b,Item:{id:"minecraft:pink_dye",Count:1b,tag:{CustomModelData:23241}}}] run data merge entity @s {PickupDelay:20,Item:{tag:{Trim:{material:"dragon_template:cherry_blossom",pattern:"dragon_template:dragon"}}}}

execute at @e[type=item,tag=craft_dragon_temlate_1] at @e[type=item,tag=craft_ingredients_2,distance=..0.5,limit=1] as @e[type=item,tag=craft_armor_piece_3,distance=..0.5,limit=1,sort=nearest] run tag @s add itemkill1


execute at @e[type=item,tag=craft_dragon_temlate_1] at @e[type=item,tag=craft_ingredients_2,distance=..0.5,limit=1] as @e[type=item,tag=craft_armor_piece_3,distance=..0.5,limit=1,sort=nearest] run particle minecraft:item smithing_table ~ ~.4 ~ .2 .2 .2 0 15
execute at @e[type=item,tag=craft_dragon_temlate_1] at @e[type=item,tag=craft_ingredients_2,distance=..0.5,limit=1] as @e[type=item,tag=craft_armor_piece_3,distance=..0.5,limit=1,sort=nearest] run playsound minecraft:item.axe.scrape neutral @a[distance=..7] ~ ~ ~ 5 1
execute at @e[type=item,tag=craft_dragon_temlate_1] at @e[type=item,tag=craft_ingredients_2,distance=..0.5,limit=1] as @e[type=item,tag=craft_armor_piece_3,distance=..0.5,limit=1,sort=nearest] run playsound minecraft:block.anvil.use neutral @a[distance=..7] ~ ~ ~ 5 1
execute at @e[type=item,tag=craft_dragon_temlate_1] at @e[type=item,tag=craft_ingredients_2,distance=..0.5,limit=1] as @e[type=item,tag=craft_armor_piece_3,distance=..0.5,limit=1,sort=nearest] run playsound minecraft:block.smithing_table.use neutral @a[distance=..7] ~ ~ ~ 5 1
execute as @e[type=item,tag=itemkill1] at @s run kill @e[type=item,tag=craft_dragon_temlate_1,distance=..1]
execute as @e[type=item,tag=itemkill1] at @s run kill @e[type=item,tag=craft_ingredients_2,distance=..1]
tag @e[type=item,tag=itemkill1] remove craft_armor_piece_3

schedule function extra_items:dragon_template_smithing 1s replace 