execute as @e[scores={cherrytana_hit=1..},nbt={SelectedItem:{tag:{CustomModelData:23241}}}] at @s positioned ~ ~1.5 ~ run summon area_effect_cloud ^-0.75 ^ ^1.5 {Tags:[Cherry_Slash],Duration:5}
execute as @e[scores={cherrytana_hit=1..},nbt={SelectedItem:{tag:{CustomModelData:23241}}}] at @s positioned ~ ~1.5 ~ positioned ^-0.75 ^ ^1.5 run tp @e[limit=1,sort=nearest,tag=Cherry_Slash] ~ ~ ~ ~ ~
execute as @e[scores={cherrytana_hit=1..},nbt={SelectedItem:{tag:{CustomModelData:23241}}}] at @s anchored eyes positioned ^ ^ ^2.5 run scoreboard players add @e[limit=3,sort=nearest,distance=..2.49] cherry_effect 20
execute as @e[scores={cherrytana_hit=1..},nbt={SelectedItem:{tag:{CustomModelData:23241}}}] at @s anchored eyes positioned ^ ^ ^2.5 as @e[limit=3,sort=nearest,distance=..2.49] run function extra_items:cherrytana_dmg
scoreboard players reset @e cherrytana_hit

#cherry slash anim
execute as @e[tag=Cherry_Slash] at @s run particle minecraft:item pink_glazed_terracotta ~ ~ ~ 0.25 0.25 0.25 0.1 7 normal
execute as @e[tag=Cherry_Slash] at @s run particle minecraft:item cherry_leaves ~ ~ ~ 0.25 0.25 0.25 0.1 5 normal
execute as @e[tag=Cherry_Slash] at @s run playsound minecraft:block.cherry_leaves.break neutral @a[distance=..10] ~ ~ ~ 3 1 1.0
execute as @e[tag=Cherry_Slash] at @s run tp @s ^0.3 ^ ^