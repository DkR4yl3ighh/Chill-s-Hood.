execute as @a[scores={ate_cherries=1..,cherries_SI=1}] run effect give @s resistance 5 0
execute as @a[scores={ate_golden_cherries=1..,golden_cherries_SI=1}] run effect give @s resistance 20 2
scoreboard players reset @a ate_cherries
scoreboard players reset @a ate_golden_cherries
scoreboard players reset @a cherries_SI
execute as @e[nbt={SelectedItem:{id:"minecraft:apple",tag:{CustomModelData:23241}}}] run scoreboard players set @s cherries_SI 1
scoreboard players reset @a golden_cherries_SI
execute as @e[nbt={SelectedItem:{id:"minecraft:apple",tag:{CustomModelData:23242}}}] run scoreboard players set @s golden_cherries_SI 1