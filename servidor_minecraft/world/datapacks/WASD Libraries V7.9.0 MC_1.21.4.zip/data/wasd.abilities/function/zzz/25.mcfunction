#mc-build WASD content
execute unless block ~ ~-0.5 ~ #wasd.tags:nonsolid positioned ^ ^ ^5 run function wasd.lib:math/apply_motion
execute if block ~ ~-0.5 ~ #wasd.tags:nonsolid positioned ^ ^-2 ^3 run function wasd.lib:math/apply_motion
execute unless block ^ ^ ^0.7 #wasd.tags:nonsolid on passengers as @s[type=marker,tag=wasd.temp_minecart] run function wasd.abilities:zzz/26