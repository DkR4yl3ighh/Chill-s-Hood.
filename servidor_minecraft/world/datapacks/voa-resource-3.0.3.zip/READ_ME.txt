Sound Credit - I did not make a majority of the custom sounds found in this resourcepack.

A big special thanks to the following folks:

Abomination Damage- https://freesound.org/people/Yudena/sounds/377580/
Abomination- https://freesound.org/people/jessepash/sounds/235376/
Abomination- https://freesound.org/people/InspectorJ/sounds/401943/
Abyssal Horror- https://freesound.org/people/gabemiller74/sounds/50881/
Abyssal Horror- https://freesound.org/people/Timbre/sounds/203702/
Abyssal Horror- https://freesound.org/people/Robinhood76/sounds/161488/
Boss Defeat Music- https://freesound.org/people/tim.kahn/sounds/152723/
Gun Sound - https://freesound.org/people/TheNikonProductions/sounds/337698/
Musket Sound- https://freesound.org/people/mlsulli/sounds/234869/
Magic Sound- https://freesound.org/people/fredzed/sounds/416386/
Magic Sound- https://freesound.org/people/Chanhun/sounds/161322/
Magic Sound- https://freesound.org/people/InspectorJ/sounds/411460/
Magic Sound- https://freesound.org/people/MATRIXXX_/sounds/462092/
Spectre- https://freesound.org/people/HorrorAudio/sounds/507451/
Spectre- https://freesound.org/people/toam/sounds/193688/
Titan Sound -https://freesound.org/people/JonCon_Library/sounds/481642/
Titan Damage? - https://freesound.org/people/Groadr/sounds/253471/
Titan Growl -https://freesound.org/people/ztrees1/sounds/134931/
Warped Titan -https://freesound.org/people/cusconauta/sounds/234297/
Warped Titan -https://freesound.org/people/wluna/sounds/216046/
Warped Titan -https://freesound.org/people/lendrick/sounds/77637/
Wraith Damage- https://freesound.org/people/squashy555/sounds/240091/
Nether Demon-https://freesound.org/people/cylon8472/sounds/249686/
Nether Demon-https://freesound.org/people/nicholas03/sounds/570504/
Gila Monster-https://freesound.org/people/InfamousLazure/sounds/686024/
Gila Monster-https://freesound.org/people/quetzalcontla/sounds/419794/
Gila Monster-https://freesound.org/people/charlesart/sounds/513290/
Reaper-https://freesound.org/people/BloodPixelHero/sounds/646406/
Reaper-https://freesound.org/people/CreepyDanny1234/sounds/559390/
Reaper-https://freesound.org/people/VitaWrap/sounds/207292/
Reaper-https://freesound.org/people/MrWinter/sounds/370193/
Reaper-https://freesound.org/people/thanvannispen/sounds/125134/
Ender Demon-https://freesound.org/people/LittleRobotSoundFactory/sounds/316393/
Ender Demon-https://freesound.org/people/MATRIXXX_/sounds/527636/
Ender Demon-https://freesound.org/people/Bertsz/sounds/524305/
