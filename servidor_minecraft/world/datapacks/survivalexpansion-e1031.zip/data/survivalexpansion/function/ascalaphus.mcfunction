bossbar set minecraft:ascalaphus visible true
execute as @e[tag=SummonAscalaphus2] at @s run kill @e[type=leash_knot,tag=particle]
execute as @e[tag=SummonAscalaphus2] at @s run setblock ~2 ~2 ~2 blue_ice
execute as @e[tag=SummonAscalaphus2] at @s run setblock ~-2 ~2 ~-2 blue_ice
execute as @e[tag=SummonAscalaphus2] at @s run setblock ~-2 ~2 ~2 blue_ice
execute as @e[tag=SummonAscalaphus2] at @s run setblock ~2 ~2 ~-2 blue_ice
execute as @e[tag=SummonAscalaphus2] at @s run playsound minecraft:entity.ghast.warn ambient @a[distance=..100] ~ ~ ~ 15 0
execute as @e[tag=SummonAscalaphus2] at @s run playsound minecraft:entity.generic.explode ambient @a[distance=..100] ~ ~ ~ 15 1
execute as @e[tag=SummonAscalaphus2] at @s run playsound entity.wither.spawn ambient @a[distance=..100] ~ ~ ~ 15 0
execute as @e[tag=SummonAscalaphus2] at @s run particle explosion_emitter
execute as @e[tag=SummonAscalaphus2] at @s run summon ghast ~ ~10 ~ {Silent:1b,Glowing:1b,Team:"AscalaphusGlow",PersistenceRequired:1b,Health:100f,ExplosionPower:4,Tags:["ascalaphus"],CustomName:'{"text":"Ascalaphus"}',HandItems:[{id:"minecraft:ghast_tear",count:1,components:{"minecraft:item_model":"minecraft:ichortear","minecraft:custom_name":'{"color":"yellow","italic":false,"text":"Ichor Tear"}',"minecraft:enchantments":{levels:{"minecraft:protection":1},show_in_tooltip:false}}},{}],HandDropChances:[1.000F,0.085F],ArmorItems:[{id:"minecraft:netherite_boots",count:1,components:{"minecraft:enchantments":{levels:{"minecraft:blast_protection":4}}}},{id:"minecraft:netherite_leggings",count:1,components:{"minecraft:enchantments":{levels:{"minecraft:blast_protection":4}}}},{id:"minecraft:netherite_chestplate",count:1,components:{"minecraft:enchantments":{levels:{"minecraft:blast_protection":4}}}},{id:"minecraft:netherite_helmet",count:1,components:{"minecraft:enchantments":{levels:{"minecraft:blast_protection":4}}}}],ArmorDropChances:[0.000F,0.000F,0.000F,0.000F],attributes:[{id:"minecraft:follow_range",base:1000},{id:"minecraft:max_health",base:100},{id:"minecraft:scale",base:1.5}]}
kill @e[tag=SummonAscalaphus2]