scoreboard players add DelayT Sounds 1
execute if score DelayT Sounds matches 140 run execute as @e[type=zombie,nbt={CustomName:'{"bold":true,"color":"dark_red","text":"Dread Guardian"}'}] at @s run playsound entity.zombie.ambient ambient @a[distance=0..50] ~ ~ ~ 1 0
execute if score DelayT Sounds matches 140 run execute as @e[type=zombie,nbt={CustomName:'{"bold":true,"color":"yellow","text":"Haven Guardian"}'}] at @s run playsound entity.zombie.ambient ambient @a[distance=0..50] ~ ~ ~ 1 0
execute if score DelayT Sounds matches 140 run execute as @e[type=zombie,nbt={CustomName:'{"color":"red","text":"The Dreadknight"}'}] at @s run playsound entity.zombie.ambient ambient @a[distance=0..50] ~ ~ ~ 1 0
execute if score DelayT Sounds matches 140 run execute as @e[type=ghast,nbt={Silent:1b},name=Ascalaphus] at @s run playsound entity.ghast.ambient ambient @a[tag=asrange] ~ ~ ~ 15 0
execute if score DelayT Portals matches 250 run execute as @e[type=armor_stand,name=dreadportal,nbt={Small:1b}] at @s run playsound minecraft:block.beacon.power_select ambient @a[distance=0..50] ~ ~ ~ 1 0
execute if score DelayT Portals matches 250 run execute as @e[type=armor_stand,name=havenportal,nbt={Small:1b}] at @s run playsound minecraft:block.beacon.power_select ambient @a[distance=0..50] ~ ~ ~ 1 1.5
execute if score DelayT Sounds matches 140 run scoreboard players reset DelayT Sounds
execute if score DelayT Portals matches 250 run scoreboard players reset DelayT Portals